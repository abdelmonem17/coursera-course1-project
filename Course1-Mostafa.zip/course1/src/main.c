

#include "memory.h"
#include "platform.h"
#include "course1.h"

int main(void) {
 
#ifdef COURSE1

	course1();
#endif 

  return 0;
}

