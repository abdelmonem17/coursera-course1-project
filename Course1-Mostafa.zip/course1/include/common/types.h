#ifndef _TYPES_H_
#define _TYPES_H_

typedef char int_8t;
typedef unsigned char uint_8t;
typedef short int uint_16t;
typedef long int int_32t;
typedef unsigned long int uint_32t;

#endif
